Ext.define('YelpExtplorer.view.Banner', {
    extend: 'Ext.Component',
    xtype: 'banner',
    height: 36,
    html: '<img src="resources/images/YelpExtplorerLogo.png" />'
});