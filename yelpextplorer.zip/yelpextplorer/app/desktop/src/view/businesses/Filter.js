Ext.define('YelpExtplorer.view.businesses.Filter', {
    extend: 'Ext.toolbar.Toolbar',
    xtype: 'businessesfilter',

    requires: [
        'Ext.toolbar.Spacer'
    ],

    items: [{
        xtype: 'textfield',
        fieldLabel: 'City',
        labelWidth: 26,
        bind: {
            value: '{typedCity}'
        }
    }, {
        xtype: 'tbspacer'
    }, {
        xtype: 'textfield',
        fieldLabel: 'Category',
        labelWidth: 52,
        bind: {
            value: '{typedCategory}'
        }
    }],
    padding: 4
});