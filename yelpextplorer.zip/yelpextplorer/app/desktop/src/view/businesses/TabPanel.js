Ext.define("YelpExtplorer.view.businesses.TabPanel", {
    extend: "Ext.tab.Panel",
    xtype: 'businessestabpanel',

    requires: [
        'YelpExtplorer.view.businesses.Map'
    ],

    reference: 'businessestabpanel',

    items: [{
        title: 'Map',
        itemId: 'map',
        xtype: 'businessesmap',
        bind: {
            location: '{location}',
            store: '{businesses}',
            selection: '{business}'
        }
    }, {
        title: 'View',
        itemId: 'view',
        xtype: 'businessesview',
        bind: {
            store: '{businesses}',
            selection: '{business}'
        }
    }, {
        title: 'Grid',
        itemId: 'grid',
        xtype: 'businessesgrid',
        bind: {
            store: '{sortableBusinesses}',
            selection: '{business}'
        }
    }, {
        title: 'Chart',
        html: 'businesseschart'
    }]

});