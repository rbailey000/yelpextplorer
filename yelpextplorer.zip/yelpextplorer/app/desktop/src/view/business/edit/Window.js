Ext.define('YelpExtplorer.view.business.edit.Window', {
    extend: 'Ext.window.Window',
    xtype: 'editbusinesswindow',
    requires: [
        'YelpExtplorer.view.business.edit.WindowController',
        'Ext.form.Panel',
        //'Ext.ux.rating.Picker',
    ],
    controller: 'business-edit-window',
    resizable: false,
    bodyPadding: 8,
    modal: true,

    layout: 'fit',

    items: [{
        xtype: 'form',
        reference: 'form',
        modalValidation: true,
        items: [{
            fieldLabel: 'Name'
        }, {
            // Text field goes here
            xtype: 'textfield',
            bind: {
                value: '{business.name}'
            }
        }, {
            // Ratings widget
            xtype: 'rating',
            rounding: 0.5,
            minimum: 1, // Yelp ratings go from 1 - 5
            maximum: 5,
            selectedStyle: 'color: #ff4444', // Pale red
            overStyle: 'color: #ff0000', // Red
            bind: {
                value: '{business.rating}'
            }
        }],
        buttons: [{
            text: 'Save',
            formBind: true,
            handler: 'onSaveClick'
        }, {
            text: 'Cancel',
            handler: 'onCancelClick'
        }]
    }]
});