Ext.define('YelpExtplorer.view.main.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.main-main'

});
