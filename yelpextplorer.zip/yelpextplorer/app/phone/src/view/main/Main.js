Ext.define('YelpExtplorer.view.main.Main', {
    extend: 'Ext.Panel',
    xtype: 'main',
    requires: [
        'YelpExtplorer.view.main.MainController',
        'YelpExtplorer.view.main.MainModel'
    ],

    controller: 'main-main',
    viewModel: {
        type: 'main-main'
    },
    bodyPadding: 8,
    html: '<span style="font-weight:bold;font-size:24px;font-style:italic;color:red">My Phone\'s Main View</span>'
});